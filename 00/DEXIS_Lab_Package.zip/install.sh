#!/bin/bash
echo 'Installing DEXIS Lab...'